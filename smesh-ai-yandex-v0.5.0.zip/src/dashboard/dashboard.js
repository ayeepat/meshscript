/**
 * Full-window dashboard: week-of-homework sidebar + chat solve view.
 * Each sidebar lesson keeps its own chat in this tab. The AI is only called
 * when a lesson is opened for the first time (or you send a follow-up).
 * Chat history (7-day TTL) lives in Settings, not here.
 */
import { initTheme, toggleTheme } from '../common/theme.js';
import { extractMath, restoreMath } from '../common/tex.js';
import { iconSvg } from '../common/icons.js';
import { startThinking } from '../common/thinking.js';

// Keep the theme button icon in sync with the resolved theme.
document.addEventListener('themechange', (e) => {
  document.getElementById('themeBtn').innerHTML = iconSvg(e.detail === 'dark' ? 'sun' : 'moon', 16);
});
initTheme();

const params = new URLSearchParams(location.search);
const initialSubject = params.get('subject') || '';
const initialTask = params.get('task') || '';
const initialDay = params.get('day') || '';

const chatEl = document.getElementById('chat');
const titleEl = document.getElementById('title');
const weekEl = document.getElementById('week');

// key -> { key, day, subject, task, sessionId, history: [{role, content}], started, pending }
const chats = new Map();
let activeKey = null;
let answerMode = 'brief'; // 'brief' (concise, keeps steps) | 'explain' (tutor)

// Task is part of the key: one subject can have two homeworks in a day.
const keyFor = (day, subject, task) => `${day || '?'}||${subject}||${(task || '').slice(0, 40)}`;
const activeChat = () => chats.get(activeKey);

// The task string scraped into the week can differ from the one passed via the
// Solve URL by whitespace or truncation. Compare on a normalized 40-char prefix
// (same granularity as keyFor) so a file the user attached for THIS solve isn't
// silently dropped over a trivial text mismatch, while still refusing to attach
// it to an unrelated homework of the same subject.
const normTask = (t) => (t || '').replace(/\s+/g, ' ').trim().slice(0, 40);

/* ---------- Minimal safe markdown renderer (no external libs) ---------- */

function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function inlineMd(s) {
  return s
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
}

function mdToHtml(md) {
  // Pull LaTeX out first so markdown processing can't mangle *, _ inside it.
  const { text, chunks } = extractMath(md);
  const lines = escapeHtml(text).split(/\r?\n/);
  let html = '';
  let list = null; // 'ul' | 'ol'
  const closeList = () => { if (list) { html += `</${list}>`; list = null; } };
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) { closeList(); continue; }
    const h = line.match(/^#{1,6}\s+(.*)$/);
    if (h) { closeList(); html += `<h4>${inlineMd(h[1])}</h4>`; continue; }
    const ul = line.match(/^[*\-•]\s+(.*)$/);
    if (ul) {
      if (list !== 'ul') { closeList(); html += '<ul>'; list = 'ul'; }
      html += `<li>${inlineMd(ul[1])}</li>`; continue;
    }
    const ol = line.match(/^\d+[.)]\s+(.*)$/);
    if (ol) {
      if (list !== 'ol') { closeList(); html += '<ol>'; list = 'ol'; }
      html += `<li>${inlineMd(ol[1])}</li>`; continue;
    }
    closeList();
    html += `<p>${inlineMd(line)}</p>`;
  }
  closeList();
  return restoreMath(html, chunks);
}

/* ---------- Typewriter: starts slow, accelerates, finishes fast ---------- */

// Re-parsing the full markdown every frame is O(n²); for long answers that
// janks badly and the reveal drags on. Above this length we render once.
const TYPEWRITER_MAX = 1500;

function typewriter(el, fullText) {
  if (fullText.length > TYPEWRITER_MAX) { el.innerHTML = mdToHtml(fullText); return; }
  let i = 0;
  let chunk = 1; // chars per frame; grows each frame -> accelerating reveal
  function step() {
    if (!el.isConnected) return; // user switched lessons mid-animation
    i += Math.round(chunk);
    chunk = Math.min(chunk * 1.08 + 0.3, 60);
    el.innerHTML = mdToHtml(fullText.slice(0, i));
    chatEl.scrollTop = chatEl.scrollHeight;
    if (i < fullText.length) requestAnimationFrame(step);
    else el.innerHTML = mdToHtml(fullText); // final clean render
  }
  requestAnimationFrame(step);
}

/* ---------- Chat UI ---------- */

function copyButton(getText) {
  const b = document.createElement('button');
  b.className = 'copybtn';
  b.title = 'Скопировать ответ';
  b.innerHTML = iconSvg('copy', 13);
  b.onclick = async () => {
    try {
      await navigator.clipboard.writeText(getText());
      b.innerHTML = iconSvg('check', 13);
      setTimeout(() => (b.innerHTML = iconSvg('copy', 13)), 1200);
    } catch (_e) { /* clipboard blocked — ignore */ }
  };
  return b;
}

/** Chip shown on a user message when files were attached: green check + icon. */
function attachChip(files) {
  const chip = document.createElement('div');
  chip.className = 'attachchip';
  const icon = (files.length === 1 && (files[0].mimeType || '').startsWith('image/')) ? 'image' : 'file';
  const label = files.length === 1
    ? (files[0].name || 'файл')
    : `${files.length} файла`;
  chip.innerHTML =
    `<span class="ac-check">${iconSvg('check', 13)}</span>` +
    `<span class="ac-ico">${iconSvg(icon, 13)}</span>` +
    `<span class="ac-name"></span>`;
  chip.querySelector('.ac-name').textContent = label;
  return chip;
}

function bubble(role, text, { animate = false, files = null, needsUpload = false } = {}) {
  const d = document.createElement('div');
  d.className = `msg ${role}`;
  if (role === 'assistant') {
    // Gate refusals (no readable file) read as a clear "attach a file" prompt.
    if (needsUpload) {
      d.classList.add('needupload');
      const head = document.createElement('div');
      head.className = 'nu-head';
      head.innerHTML = `${iconSvg('upload', 14)}<span>Нужен файл</span>`;
      d.appendChild(head);
    }
    const body = document.createElement('div');
    body.className = 'mdbody';
    if (animate) typewriter(body, text);
    else body.innerHTML = mdToHtml(text);
    d.appendChild(body);
    d.appendChild(copyButton(() => text));
  } else {
    const span = document.createElement('div');
    span.className = 'usertext';
    span.textContent = text; // user text stays plain
    d.appendChild(span);
    if (files?.length) d.appendChild(attachChip(files));
  }
  chatEl.appendChild(d);
  chatEl.scrollTop = chatEl.scrollHeight;
  return d;
}

/** Empty assistant bubble whose body is filled live as tokens stream in. */
function assistantShell() {
  const d = document.createElement('div');
  d.className = 'msg assistant';
  const body = document.createElement('div');
  body.className = 'mdbody';
  d.appendChild(body);
  chatEl.appendChild(d);
  chatEl.scrollTop = chatEl.scrollHeight;
  return { wrap: d, body };
}

/**
 * Transient status bubble shown while the answer is being generated. The verb
 * shifts and an elapsed-seconds counter ticks (see common/thinking.js), so a
 * long solve never looks frozen — same feedback as the test tab.
 */
function thinkingBubble() {
  const d = document.createElement('div');
  d.className = 'msg assistant thinking';
  chatEl.appendChild(d); // append BEFORE animating so the ticker sees it connected
  d.__ticker = startThinking(d);
  chatEl.scrollTop = chatEl.scrollHeight;
  return d;
}

// Stop a chat's thinking ticker and remove its bubble. Always pair the two so a
// removed bubble never leaks its interval.
function stopThinking(chat) {
  if (!chat.thinkingEl) return;
  chat.thinkingEl.__ticker?.stop();
  chat.thinkingEl.remove();
  chat.thinkingEl = null;
}

/** Re-render the whole chat from a lesson's stored history (no animation). */
function renderChat(chat) {
  chatEl.innerHTML = '';
  if (!chat) {
    chatEl.innerHTML = '<p class="hintmsg">Выберите урок слева, чтобы получить решение.</p>';
    return;
  }
  const card = gdzCardEl(chat); // GDZ answers sit above the chat
  if (card) chatEl.appendChild(card);
  for (const m of chat.history) bubble(m.role, m.content, { files: m.files, needsUpload: m.needsUpload });
  if (chat.pending) chat.thinkingEl = thinkingBubble();
}

/* ---------- Image lightbox (click a GDZ answer to enlarge) ---------- */

// One overlay reused for every image. Built lazily so the dashboard pays for it
// only if the user actually opens an answer scan.
let lightboxEl = null;
let lastFocused = null;

function ensureLightbox() {
  if (lightboxEl) return lightboxEl;
  const ov = document.createElement('div');
  ov.className = 'lightbox';
  ov.hidden = true;
  ov.innerHTML =
    `<button class="lb-close" type="button" title="Закрыть (Esc)" aria-label="Закрыть">${iconSvg('close', 22)}</button>` +
    `<div class="lb-stage"><img class="lb-img" alt="" /></div>`;
  ov.querySelector('.lb-close').addEventListener('click', closeLightbox);
  // Click on the dark backdrop (anywhere but the image itself) closes.
  ov.addEventListener('click', (e) => { if (e.target !== ov.querySelector('.lb-img')) closeLightbox(); });
  // Click the image to toggle fit-to-screen ↔ actual size (pan by scrolling).
  const img = ov.querySelector('.lb-img');
  img.addEventListener('click', (e) => { e.stopPropagation(); img.classList.toggle('zoomed'); });
  document.body.appendChild(ov);
  lightboxEl = ov;
  return ov;
}

function openLightbox(src, alt) {
  const ov = ensureLightbox();
  const img = ov.querySelector('.lb-img');
  img.classList.remove('zoomed');
  img.src = src;
  img.alt = alt || '';
  ov.hidden = false;
  document.body.classList.add('lb-open');
  lastFocused = document.activeElement;
  ov.querySelector('.lb-close').focus();
}

function closeLightbox() {
  if (!lightboxEl || lightboxEl.hidden) return;
  lightboxEl.hidden = true;
  // Drop the (possibly multi-MB) data URL so it isn't pinned in memory.
  lightboxEl.querySelector('.lb-img').src = '';
  document.body.classList.remove('lb-open');
  if (lastFocused?.isConnected) lastFocused.focus();
  lastFocused = null;
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && lightboxEl && !lightboxEl.hidden) { e.preventDefault(); closeLightbox(); }
});

/* ---------- GDZ answers (ready textbook solutions, no AI) ---------- */

/** Build the GDZ answer card from a lesson's resolved data, or null. */
function gdzCardEl(chat) {
  const g = chat.gdz;
  const found = (g?.answers || []).filter((a) => a.found && a.inlined?.length);
  if (!found.length) return null;

  const card = document.createElement('div');
  card.className = 'gdzcard';
  card.dataset.key = chat.key;

  const head = document.createElement('div');
  head.className = 'gh';
  head.innerHTML = `${iconSvg('book', 14)}<span>Готовые ответы · ГДЗ</span>`;
  card.appendChild(head);

  const bookLabel = (bk) => [bk?.breadcrumb || bk?.title, bk?.year].filter(Boolean).join(' · ');
  // When every answer comes from one book, show the source once in the header.
  // With a textbook + workbook mixed, label each answer with its own source.
  const sources = new Set(found.map((a) => bookLabel(a.book || g.book)).filter(Boolean));
  const singleSource = sources.size <= 1;
  if (singleSource) {
    const prov = bookLabel(g.book) || [...sources][0];
    if (prov) {
      const sub = document.createElement('div');
      sub.className = 'gsub';
      sub.textContent = prov;
      card.appendChild(sub);
    }
  }

  for (const a of found) {
    const block = document.createElement('div');
    block.className = 'gdzanswer';
    const label = document.createElement('div');
    label.className = 'gnum';
    const mode = a.mode || g.mode;
    label.textContent = mode === 'page' ? `Страница ${a.num}` : `№ ${a.num}`;
    if (!singleSource) {
      const src = bookLabel(a.book);
      if (src) {
        const s = document.createElement('span');
        s.className = 'gsrc';
        s.textContent = src;
        label.appendChild(s);
      }
    }
    block.appendChild(label);
    for (const img of a.inlined) {
      const im = document.createElement('img');
      im.src = `data:${img.mimeType};base64,${img.dataBase64}`;
      const alt = mode === 'page' ? `ГДЗ — страница ${a.num}` : `ГДЗ № ${a.num}`;
      im.alt = alt;
      im.loading = 'lazy';
      // Answer scans are small in the card but full of fine print — make them
      // openable in a fullscreen lightbox to actually read them.
      im.tabIndex = 0;
      im.setAttribute('role', 'button');
      im.title = 'Нажмите, чтобы увеличить';
      im.addEventListener('click', () => openLightbox(im.src, alt));
      im.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openLightbox(im.src, alt); }
      });
      block.appendChild(im);
    }
    if (a.link) {
      const link = document.createElement('a');
      link.href = a.link;
      link.target = '_blank';
      link.rel = 'noopener';
      link.textContent = 'Открыть на ГДЗ →';
      block.appendChild(link);
    }
    card.appendChild(block);
  }
  return card;
}

/** Resolve textbook references for this lesson and show the answer card BEFORE
 *  the AI solve — when ready GDZ answers exist they replace the AI call, so the
 *  lookup intentionally gates the solve. The card is prepended above the chat. */
/** @returns {Promise<boolean>} whether ready GDZ answers were found. */

// Hard ceiling on the GDZ lookup. The resolve hits gdz-ru.com (book structure +
// answer images) and the MV3 service worker can be recycled mid-request — either
// could otherwise leave the lesson awaiting a reply that never comes, stranding
// the user on a blank chat. On timeout we give up on GDZ and fall through to the
// AI solve. Generous enough that a normal resolve (now parallelised) finishes
// well within it, so we don't trigger a wasted AI call on the happy path.
const GDZ_LOOKUP_TIMEOUT_MS = 25000;

async function maybeShowGdz(chat) {
  let resp;
  try {
    resp = await new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (!done) { done = true; resolve(v); } };
      const timer = setTimeout(() => finish(null), GDZ_LOOKUP_TIMEOUT_MS);
      chrome.runtime.sendMessage(
        { type: 'GDZ_FOR_TASK', payload: { subject: chat.subject, task: chat.task } },
        (r) => { clearTimeout(timer); finish(chrome.runtime.lastError ? null : r); }
      );
    });
  } catch { return false; }
  if (!resp?.ok || !resp.configured) return false;
  const found = (resp.answers || []).filter((a) => a.found && a.inlined?.length);
  if (!found.length) return false;

  chat.gdz = { book: resp.book, mode: resp.mode, answers: resp.answers };
  if (activeKey === chat.key && !chatEl.querySelector(`.gdzcard[data-key="${CSS.escape(chat.key)}"]`)) {
    chatEl.insertBefore(gdzCardEl(chat), chatEl.firstChild);
  }
  return true;
}

function fileToInline(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve({ mimeType: file.type || 'application/octet-stream', dataBase64: String(r.result).split(',')[1], name: file.name });
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

/**
 * Send a message within a lesson's chat over a streaming port. Tokens are
 * revealed live; the answer is appended to that lesson's history even if the
 * user switched lessons meanwhile — the DOM is only touched when the lesson is
 * the active one. The active lesson can change mid-stream, so every render
 * guards on `activeKey === chat.key`.
 */
function sendToChat(chat, text, files) {
  // Context BEFORE this message. Drop gate refusals (the "пришлите фото / нужен
  // файл" prompts): they're UI nudges, not real conversation, and replaying
  // them as assistant turns biases the next answer's tone.
  const prior = chat.history.filter((m) => !m.needsUpload);
  // Keep the FULL files (incl. base64) on the user turn. The chip only reads
  // name/mime, but the service worker replays history attachments to the model
  // so a follow-up question still "sees" the photo/PDF from an earlier turn.
  // Bounded by MAX_HISTORY_MESSAGES in the service worker.
  const turnFiles = files || [];
  chat.history.push({ role: 'user', content: text, files: turnFiles });
  chat.pending = true;
  if (activeKey === chat.key) {
    bubble('user', text, { files: turnFiles });
    chat.thinkingEl = thinkingBubble();
  }
  renderSidebar();

  return new Promise((resolve) => {
    const port = chrome.runtime.connect({ name: 'solve' });
    let acc = '';        // accumulated streamed text
    let shell = null;    // live assistant bubble, created on first delta
    let settled = false;

    // (Re)create the live bubble. Switching lessons wipes the chat DOM via
    // renderChat, detaching our shell — so rebuild it (with text so far) if the
    // user comes back mid-stream.
    const ensureShell = () => {
      if (activeKey !== chat.key) return;
      if (shell && shell.wrap.isConnected) return;
      stopThinking(chat);
      shell = assistantShell();
      shell.body.innerHTML = mdToHtml(acc);
    };

    // Re-parsing the full markdown on every token is O(n²) and janks on long
    // answers. Coalesce AND throttle: deltas just append to `acc`; the DOM
    // re-parses at most once per RENDER_THROTTLE_MS (not once per frame), which
    // keeps the work bounded as the answer grows. `finish()` does the final
    // clean render, so throttling never affects the result the user ends on.
    const RENDER_THROTTLE_MS = 90;
    let renderPending = false;
    let lastRender = 0;
    const doFlush = () => {
      renderPending = false;
      lastRender = performance.now();
      if (settled || activeKey !== chat.key) return;
      ensureShell();
      shell.body.innerHTML = mdToHtml(acc);
      chatEl.scrollTop = chatEl.scrollHeight;
    };
    const scheduleRender = () => {
      if (renderPending || activeKey !== chat.key) return;
      renderPending = true;
      const wait = Math.max(0, RENDER_THROTTLE_MS - (performance.now() - lastRender));
      setTimeout(() => requestAnimationFrame(doFlush), wait);
    };

    const finish = (answer, { animate = false, needsUpload = false } = {}) => {
      if (settled) return;
      settled = true;
      chat.pending = false;
      chat.history.push({ role: 'assistant', content: answer, needsUpload });
      if (activeKey === chat.key) {
        stopThinking(chat);
        if (shell && shell.wrap.isConnected) {
          shell.body.innerHTML = mdToHtml(answer); // clean final render
          shell.wrap.appendChild(copyButton(() => answer));
        } else {
          bubble('assistant', answer, { animate, needsUpload });
        }
      }
      renderSidebar();
      try { port.disconnect(); } catch { /* already gone */ }
      resolve();
    };

    port.onMessage.addListener((m) => {
      if (m?.type === 'delta') {
        acc += m.text;
        scheduleRender();
      } else if (m?.type === 'done') {
        chat.sessionId = m.result?.sessionId || chat.sessionId;
        // Prefer the authoritative full text; fall back to what we streamed.
        // animate only when nothing streamed (e.g. the photo-request guard).
        finish(m.result?.answer ?? acc, { animate: !acc, needsUpload: !!m.result?.needsUpload });
      } else if (m?.type === 'error') {
        finish('Ошибка: ' + m.error);
      }
    });

    // The service worker can be torn down; surface that instead of hanging.
    port.onDisconnect.addListener(() => finish(acc || 'Ошибка: соединение прервано.'));

    port.postMessage({
      type: 'SOLVE',
      payload: { subject: chat.subject, task: text, files, sessionId: chat.sessionId, history: prior, mode: answerMode }
    });
  });
}

/**
 * First open of a lesson: send the task as-is. The subject prompt from
 * Settings is applied as the SYSTEM prompt by the service worker — sending
 * it here too would duplicate it and break the bare-"Упр. N" photo guard.
 * If the popup attached a file for this lesson, include it.
 */
async function startLesson(chat) {
  chat.started = true;
  let files = [];
  try {
    const { pendingUpload } = await chrome.storage.local.get('pendingUpload');
    // Files come from the popup: manually attached OR auto-fetched from Mesh.
    // Match on subject + day + TASK: a subject can have several homeworks on one
    // day, and matching on subject alone attached the wrong (or no) file.
    const pending = pendingUpload?.files || (pendingUpload?.file ? [pendingUpload.file] : []);
    if (pending.length && pendingUpload.subject === chat.subject &&
        (!pendingUpload.day || pendingUpload.day === chat.day) &&
        (!pendingUpload.task || normTask(pendingUpload.task) === normTask(chat.task))) {
      files = pending; // the attachment chip (added by bubble) shows the file
      await chrome.storage.local.remove('pendingUpload');
    }
  } catch (_e) { /* upload is best-effort */ }

  // Ready GDZ answers are free (no API), shown as a card above the chat. If we
  // have them and the user didn't attach a file to solve, that's the whole
  // answer: show ONLY the card — no auto AI turn, so no task echo and no
  // "Нужен файл" nudge. The user can still ask follow-ups in the composer.
  const hasGdz = await maybeShowGdz(chat);
  if (hasGdz && !files.length) return;

  await sendToChat(chat, chat.task, files);
}

async function activateLesson(key) {
  const chat = chats.get(key);
  if (!chat || key === activeKey) return;
  activeKey = key;
  titleEl.textContent = `${chat.subject} — решение`;
  renderChat(chat);
  renderSidebar();
  if (!chat.started) await startLesson(chat); // the only place the API gets triggered automatically
}

/* ---------- Sidebar: whole week, grouped by day, scrollable ---------- */

function renderSidebar() {
  weekEl.innerHTML = '';
  if (!chats.size) {
    weekEl.innerHTML = '<p class="hintmsg">Нет данных о неделе. Откройте попап на странице дневника, чтобы просканировать домашние задания.</p>';
    return;
  }
  // Group lessons by day (first-seen order) so a lesson added out of insertion
  // order — e.g. an old Solve link appended at the end — still lands under its
  // day instead of producing a second, duplicate day header further down.
  const byDay = new Map();
  for (const chat of chats.values()) {
    const day = chat.day || null;
    if (!byDay.has(day)) byDay.set(day, []);
    byDay.get(day).push(chat);
  }
  for (const [day, dayChats] of byDay) {
    const hdr = document.createElement('div');
    hdr.className = 'dayhdr';
    hdr.textContent = day || 'Без даты';
    weekEl.appendChild(hdr);
    for (const chat of dayChats) {
      const el = document.createElement('div');
      el.className = 'lesson' + (chat.key === activeKey ? ' active' : '');
      el.innerHTML = '<div class="subj"></div><div class="t"></div>';
      const subj = el.querySelector('.subj');
      if (chat.pending) {
        const dot = document.createElement('span');
        dot.className = 'spinner';
        subj.appendChild(dot);
      } else if (chat.started) {
        const done = document.createElement('span');
        done.className = 'donemark';
        done.innerHTML = iconSvg('check', 11);
        subj.appendChild(done);
      }
      subj.append(chat.subject);
      el.querySelector('.t').textContent = (chat.task || '').slice(0, 80);
      el.onclick = () => activateLesson(chat.key);
      weekEl.appendChild(el);
    }
  }
}

/* ---------- Composer ---------- */

const inputEl = document.getElementById('input');
const fileInput = document.getElementById('file');
const fileChip = document.getElementById('filechip');
const fileNameEl = document.getElementById('filename');

// Held as an already-inlined file so a pasted screenshot and a picked file
// share one path (an <input type=file> can't be set programmatically).
let pendingFile = null;

function showAttachment(name) {
  fileNameEl.textContent = name;
  fileChip.hidden = false;
}
function clearAttachment() {
  pendingFile = null;
  fileInput.value = '';
  fileChip.hidden = true;
}

document.getElementById('attach').onclick = () => fileInput.click();
fileInput.onchange = async () => {
  const f = fileInput.files[0];
  if (f) { pendingFile = await fileToInline(f); showAttachment(f.name); }
};
document.getElementById('clearfile').onclick = clearAttachment;

// Paste a screenshot / snipped image straight into the chat (Ctrl/⌘+V).
document.addEventListener('paste', async (e) => {
  const item = [...(e.clipboardData?.items || [])].find((it) => it.type.startsWith('image/'));
  if (!item) return;
  const blob = item.getAsFile();
  if (!blob) return;
  e.preventDefault();
  const name = blob.name || `screenshot-${Date.now()}.png`;
  pendingFile = await fileToInline(new File([blob], name, { type: blob.type || 'image/png' }));
  showAttachment(name);
});

async function sendFromComposer() {
  const chat = activeChat();
  if (!chat || chat.pending) return; // ignore until the current answer lands
  const text = inputEl.value.trim();
  const files = pendingFile ? [pendingFile] : [];
  if (!text && !files.length) return;
  inputEl.value = '';
  clearAttachment();
  // Text may be empty when only a file is sent — the chip shows the attachment.
  await sendToChat(chat, text, files);
}

document.getElementById('send').onclick = sendFromComposer;
inputEl.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendFromComposer();
  }
});

document.getElementById('settingsBtn').onclick = () => chrome.runtime.openOptionsPage();
document.getElementById('themeBtn').onclick = toggleTheme;

/* ---------- Answer-mode toggle (Кратко / Объяснить) ---------- */

const modeSeg = document.getElementById('modeSeg');
function markMode(mode) {
  answerMode = mode;
  for (const b of modeSeg.querySelectorAll('button')) {
    b.classList.toggle('active', b.dataset.mode === mode);
  }
}
modeSeg.addEventListener('click', (e) => {
  const b = e.target.closest('button');
  if (!b) return;
  markMode(b.dataset.mode);
  chrome.storage.local.set({ answerMode: b.dataset.mode });
});
chrome.storage.local.get('answerMode').then(({ answerMode: saved }) => {
  if (saved === 'brief' || saved === 'explain') markMode(saved);
});

/* ---------- Init: load week from the last popup scan ---------- */

(async function init() {
  const { weekHomework } = await chrome.storage.local.get('weekHomework');
  for (const group of weekHomework?.days || []) {
    for (const item of group.subjects || []) {
      const key = keyFor(group.day, item.subject, item.task);
      if (!chats.has(key)) {
        chats.set(key, {
          key, day: group.day, subject: item.subject, task: item.task,
          sessionId: null, history: [], started: false, pending: false
        });
      }
    }
  }

  // Lesson the user pressed "Solve" on. Match it against the saved week,
  // loosening the criteria step by step; if it's missing entirely (e.g.
  // opened from an old link), add it so it still works.
  let startKey = null;
  if (initialSubject) {
    const all = [...chats.values()];
    const match =
      all.find((c) => c.day === initialDay && c.subject === initialSubject && c.task === initialTask) ||
      all.find((c) => c.subject === initialSubject && c.task === initialTask) ||
      all.find((c) => c.subject === initialSubject);
    if (match) {
      startKey = match.key;
    } else {
      startKey = keyFor(initialDay, initialSubject, initialTask);
      chats.set(startKey, {
        key: startKey, day: initialDay, subject: initialSubject, task: initialTask,
        sessionId: null, history: [], started: false, pending: false
      });
    }
  }

  renderSidebar();
  if (startKey) await activateLesson(startKey);
  else renderChat(null);
})();
